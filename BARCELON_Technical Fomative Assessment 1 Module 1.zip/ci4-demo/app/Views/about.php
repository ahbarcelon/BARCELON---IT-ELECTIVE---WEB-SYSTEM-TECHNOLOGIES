<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?= base_url('assets/css/valorant.css') ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About - Basic POS System</title>
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About</a> |
        <a href="/customers">Customer Accounts</a> |
        <a href="/users">User Accounts</a>
    </nav>

    <hr>

    <div class="container">
        <h1>About the System</h1>

        <p>
            This website is the first version of a basic Point-of-Sale system
            developed using CodeIgniter 4.
        </p>

        <p>
            The Customer Accounts and User Accounts pages currently use static
            PHP arrays. A database will be added in a future version of the system.
        </p>
    </div>
</body>
</html>