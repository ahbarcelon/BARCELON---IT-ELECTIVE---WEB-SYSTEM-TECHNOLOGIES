<?php

namespace App\Controllers;

use App\Models\UserModel;

class Users extends BaseController
{
    public function index()
    {
        $userModel = new UserModel();

        $data['users'] = $userModel
            ->orderBy('id', 'ASC')
            ->findAll();

        return view('users', $data);
    }
}
