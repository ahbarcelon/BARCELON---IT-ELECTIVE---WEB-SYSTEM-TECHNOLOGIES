# POS Database Laboratory Activity Setup

This version replaces the TFA1 static PHP arrays with MySQL records loaded by
CodeIgniter 4 models.

## Files added or changed

- `.env` – local MySQL connection settings for XAMPP.
- `app/Models/CustomerModel.php` – reads the `customers` table.
- `app/Models/UserModel.php` – reads the `users` table.
- `app/Controllers/Customers.php` – gets customer records through `CustomerModel`.
- `app/Controllers/Users.php` – gets user records through `UserModel`.
- `app/Views/users.php` – displays the fields supplied by the required schema.
- `database/pos_database.sql` – creates `pos_db`, both tables, and ten sample records.

## Important schema note

The required `users` table contains `id`, `username`, `full_name`, and
`created_at`. It does not contain a `role` column. Therefore, the User Accounts
page displays `Created At` instead of the old TFA1 `Role` value. Add a `role`
column only if your instructor changes the required schema.

## Part 1: Start XAMPP

1. Open the XAMPP Control Panel.
2. Start **Apache** and **MySQL**.
3. Confirm that both services show **Running**.

If MySQL does not start, another MySQL/MariaDB service may already be using
port 3306. Stop the conflicting service or change the XAMPP MySQL port, then
update the `.env` port to match.

## Part 2: Put the project in XAMPP's web folder

Copy the `ci4-demo` folder into:

```text
C:\xampp\htdocs\ci4-demo
```

The important public entry point is:

```text
C:\xampp\htdocs\ci4-demo\public\index.php
```

## Part 3: Install/check the project from CMD

Open **Command Prompt** and run:

```bat
cd C:\xampp\htdocs\ci4-demo
php -v
composer install
php spark
```

The project requires PHP 8.2 or newer. If `php` is not recognized, use the
PHP executable included with XAMPP:

```bat
C:\xampp\php\php.exe -v
C:\xampp\php\php.exe spark
```

If Composer is not recognized, install Composer and select
`C:\xampp\php\php.exe` as its PHP executable during installation.

## Part 4: Create the MySQL database and sample records

### Option A: phpMyAdmin

1. Open `http://localhost/phpmyadmin`.
2. Click the **SQL** tab.
3. Open `database/pos_database.sql` in a text editor.
4. Copy all of its SQL statements.
5. Paste them into phpMyAdmin and click **Go**.
6. Confirm that the `pos_db` database contains `customers` and `users`.

### Option B: MySQL from CMD

From the project folder, run:

```bat
cd C:\xampp\htdocs\ci4-demo
C:\xampp\mysql\bin\mysql.exe -u root -p < database\pos_database.sql
```

When XAMPP uses the default blank root password, press **Enter** when asked
for the password. If your root account has a password, type that password.

To check the records from CMD:

```bat
C:\xampp\mysql\bin\mysql.exe -u root -p -e "USE pos_db; SELECT * FROM customers; SELECT * FROM users;"
```

## Part 5: Check the CodeIgniter database settings

The `.env` file already contains these settings:

```dotenv
app.baseURL = 'http://localhost/ci4-demo/public/'
database.default.hostname = localhost
database.default.database = pos_db
database.default.username = root
database.default.password =
database.default.DBDriver = MySQLi
database.default.DBPrefix =
database.default.port = 3306
database.default.charset = utf8mb4
database.default.DBCollat = utf8mb4_general_ci
```

If you changed the MySQL username, password, or port in XAMPP, change the same
values in `.env`.

## Part 6: Run and test the application

### Using XAMPP Apache

Open these URLs in a browser:

```text
http://localhost/ci4-demo/public/
http://localhost/ci4-demo/public/customers
http://localhost/ci4-demo/public/users
```

### Using the CodeIgniter development server

From the project folder, run:

```bat
php spark serve
```

Then open:

```text
http://localhost:8080/
http://localhost:8080/customers
http://localhost:8080/users
```

## Expected result

- `/customers` displays the five customer rows stored in MySQL.
- `/users` displays the five user rows stored in MySQL.
- The controllers no longer contain static sample arrays.
- `CustomerModel` reads from `customers`.
- `UserModel` reads from `users`.

If the pages show a database connection error, check that MySQL is running,
that `pos_db` exists, and that the `.env` username, password, and port match
your XAMPP MySQL settings.
