<?php

namespace App\Controllers;

class Customers extends BaseController
{
    public function index()
    {
        $data['customers'] = [
            [
                'full_name' => 'Juan Dela Cruz',
                'email'     => 'juan.delacruz@example.com',
                'phone'     => '09171234567',
            ],
            [
                'full_name' => 'Maria Santos',
                'email'     => 'maria.santos@example.com',
                'phone'     => '09182345678',
            ],
            [
                'full_name' => 'Paolo Reyes',
                'email'     => 'paolo.reyes@example.com',
                'phone'     => '09193456789',
            ],
            [
                'full_name' => 'Angela Garcia',
                'email'     => 'angela.garcia@example.com',
                'phone'     => '09204567890',
            ],
            [
                'full_name' => 'Joshua Mendoza',
                'email'     => 'joshua.mendoza@example.com',
                'phone'     => '09215678901',
            ],
        ];

        return view('customers', $data);
    }
}