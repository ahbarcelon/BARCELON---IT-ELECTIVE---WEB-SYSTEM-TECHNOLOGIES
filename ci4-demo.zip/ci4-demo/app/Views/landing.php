<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Basic POS System</title>
</head>
<body>
    <nav>
        <a href="/">Home</a> |
        <a href="/about">About</a> |
        <a href="/customers">Customer Accounts</a> |
        <a href="/users">User Accounts</a>
    </nav>

    <hr>

    <h1>Basic Point-of-Sale System</h1>

    <p>
        Welcome to the first version of the Basic POS System.
        Use the navigation links to view the available pages.
    </p>

    <h2>Available Features</h2>

    <ul>
        <li>View system information</li>
        <li>View customer accounts</li>
        <li>View user and staff accounts</li>
    </ul>
</body>
</html>